<?php
require "dbcon.php";
if (isset($_GET["save"])) {
    $id=$_GET["txtid"];
    $pass=$_GET["txtpass"];
    $sql="insert into login(id,password) values('$id','$pass')";
    mysqli_query($con,$sql);
    $extra="login.php";
    $host=$_SERVER['HTTP_HOST'];
    $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    echo "<script>open('http://$host$uri/$extra','self')</script>";
    
    mysqli_close($con);
}
?>