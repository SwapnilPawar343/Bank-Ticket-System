
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <script>
        function ns(){
            var n=document.getElementById("txtsi").value;
            if (n=="" || n==null) {
                    alert("Enter Valid id")
                    return false;
            
           }
           else{
              alert("Wellcome");
            return true;
        }
        
        var mob=document.getElementById("txtm").value;
         if(mob.length!=10) 
    
                {
                    alert("Eneter valid mob number");
                    return false;
                    
                }

    //     while(mob.length !=10)
    //     {
    //         alert("plise enter valid mobile no");
    //         return false;

    //     }
else{
        return true;
       
      }
    }
        </script>
         <script>
            $(document).ready(function(){
                
                $("#display").on("click","tbody tr",function(event)
                {

                    
                var values=[];
                var count=0;
                $(this).find("td").each (function()
                {
                    values[count]=$(this).text();
                    count++;
                    
                });
                $('#txtut').val(values[0]);
                $('#txtsi').val(values[1]);
                $('txtsa').val(values[2]);
                $('txtan').val(values[3]);
                
            });
        });

            
            </script>
 
    <body>
    <?php
        include("include/header.html")
        ?>
        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
        <?php
        include("include/sidemenu.html")
        ?> </div>
        
        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
            
        
        
        <div class="panel panel-info">
              <div class="panel-heading">
                    <h3 class="panel-title">Add staff</h3>
              </div>
              <div class="panel-body">
            
            <form action="savestaff.php" method="GET" role="form" onsubmit="return ns()">
                
            
            <div class="form-group">
                    <label for="">User type:-</label>            
                    <select class="form-control" required="required" id="txtut" name="txtut">
                        <option value="Bstaff">Bstaff</option>
                        <option value="admin">Admin</option>
                        <option value="staff">Staff</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="">Staff Id</label>
                    <input type="text" class="form-control" id="txtsi"name="txtsi" placeholder="Enter staff Id">
                </div>
                <div class="form-group">
                    <label for="">Staff Name</label>
                    <input type="text" class="form-control" id="txtsn"name="txtsn" placeholder="Enter Staff Name">
                </div>
                <div class="form-group">
                    <label for="">Admine Name</label>
                    <input type="text" class="form-control" id="txtan"name="txtan" placeholder="Enter admine name">
                </div>
                <label for="">branch</label>  <select name="txtbank" id="textbank" class="form-control" required="required2>
                        <option value="bank of maharastra beed">bank of maharasta beed</option>
                        <option value="bank of maharastra neknur">bank of maharastra Neknur</option>
                        <option value="bank of maharastra chousala">bank of maharastra chousala </option>
                        <option value="bank of maharastra vadvani"> bank of maharastra Vadvani</option>
                        <option value="bank of maharastra ambajogai"> bank of maharasta Ambajogai</option>
                        <option value="bank of maharastra yellambh"> bank of maharastra Yellambh</option>
                        <option value="bank of maharastra nandur">bank of maharastra Nandur</option>
                    </select>
                    
                
                <div class="form-group">
                    <label for="">Mobile.no.</label>
                    <input type="number" class="form-control" id="txtm" name="txtm" placeholder="Enter mobile number">
                </div>
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" class="form-control" id="txtpass"name="txtpass" placeholder="Enter password">
                </div>

                <div class="form-group">
                    <label for="">Re-enter Password</label>
                    <input type="Password" class="form-control" id="txtpassr"name="txtpassr" placeholder="Enter password">
                </div>







            
                
            
                <button type="submit" class="btn btn-primary" value="save" name="save">Save</button>

            </form>
            
                    </div>
                    
              </div>
              
              <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Staff Name</th>
                        <th>Admine Name</th>
                        <th>Branch</th>
                        <th>Mo.No</th>
                        <th>Option</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    require "dbcon.php";
                    $sql="select *from staff";
                   $res= mysqli_query($con,$sql);
                   while ($r=mysqli_fetch_array($res)) {
                    echo "<tr id='t1'>";
                    echo "<td>".$r[0]."</td>";
                    echo "<td>".$r[1]."</td>";
                    echo "<td>".$r[2]."</td>";
                    echo "<td>".$r[3]."</td>";
                    echo "<td><a href='savestaff.php?action=remove&id=".$r[0]."'role='button'class='btn btn-danger'><span class='glyphicon glyphicon-trash'aria-hidden='true'></span></button></td>";
                    echo "</tr>";
                
                   }
                   ?>
                
                </tbody>
              </table>
              
        </div>
        </div>
      


        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
