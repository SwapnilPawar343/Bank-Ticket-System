
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <?php
        include("include/header.html")
        ?>
        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
        <?php
        include("include/sidemenu.html")
        ?> </div>
        
        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
            
        
        
        <div class="panel panel-info">
              <div class="panel-heading">
                    <h3 class="panel-title">ticket list</h3>
              </div>
              <div class="panel-body">
            
            <form action="#" method="POST" role="form">
                
            
            <div class="form-group">
                    <label for="">Ticket no</label>
                    <input type="number" class="form-control" id="txttn"name="txttn" placeholder="Enter Ticket no">
                    </div>
                <h5><b>status</b2</h5>
                <select name="txtst" id="txtst" class="form-control" required="required" placeholder="status">
                   
                <option value="process">process</option>
                <option value="complete">complete</option>
                <option value="uncomplete">uncomplete</option>
                </select>         
        </div>
        </form>
                <button type="btn" class="btn btn-primary"onclick="bank()">Submit</button>
                
            
        </div>
                    
              </div>
              
              <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Branch</th>
                        <th>Ticket no</th>
                        <th>Subject</th>
                        <th>Massage</th>
                        <th>Attachment</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Ticket 
                            Handler
                        </th>
                        <th>Ticket Sender</th>
                       <th>Replay</th>
                              </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
              </table>
              
        </div>
        </div>
        

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
