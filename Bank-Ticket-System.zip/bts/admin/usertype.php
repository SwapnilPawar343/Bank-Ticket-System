
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script>
         function checkvalue(){ 
                var uid=document.getElementById("txtuseri").value;
                if (uid=="" || uid==null) {
                    alert("Enter Valid id")
                    return false;
                }else{
              alert("Wellcome");
            return true;}
                }
         </script>

         <script>
            $(document).ready(function(){
                
                $("#display").on("click","tbody tr",function(event)
                {

                    
                var values=[];
                var count=0;
                $(this).find("td").each (function()
                {
                    values[count]=$(this).text();
                    count++;
                    
                });
                $('#txtuseri').val(values[0]);
                $('#txtut').val(values[1]);
                
            });
        });

            
            </script>
    </head>
    <body>
        <?php
    require "dbcon.php";
    ?>
        <?php
            include("include/header.html")
        ?>
        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
            <?php
                include("include/sidemenu.html")
            ?>
        </div>
        
        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
        
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">Add user</h3>
                </div>
                <div class="panel-body">
            
                    <form action="saveusertype.php" method="get" role="form" onsubmit=" return checkvalue()">
                
            
                        <div class="form-group">
                            <label for="">User type Id</label>
                            <input type="text" class="form-control" id="txtuseri" name="txtuseri" placeholder="Enter user id">
                        </div>
                        
                        <div class="form-group">
                            <label for=>User type:-</label>            
                            <select class="form-control" id="txtut" name="txtut" required="required">
                                <option value="Bstaff">Bstaff</option>
                                <option value="admin">Admin</option>
                                <option value="staff">Staff</option>
                            </select>
                    
                        </div>
                        <button type="submit" class="btn btn-primary"value="save"name="save">Save</button>
                        </form>

                    
            
                </div>
                    
            </div>
            <?php
            include ("search.php")
            ?>
            <div class="form-group input-group col-md-offset-3 col-md-4">
            
              <input type="search" name="search" id="search" class="form-control" placeholder="search here"><span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span></div>
              <table class="table table-bordered table-hover" id="display">
                <thead>
                   
                    <tr>
                        <th>Id</th>
                        <th>User Type</th>
                        <th>option</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    require "dbcon.php";
                    $sql="select *from usertype";
                   $res= mysqli_query($con,$sql);
                   while ($r=mysqli_fetch_array($res)) {
                    echo "<tr id='t1'>";
                    echo "<td>".$r[0]."</td>";
                    echo "<td>".$r[1]."</td>";
                    echo "<td><a href='saveusertype.php?action=remove&id=".$r[0]."'role='button'class='btn btn-danger'><span class='glyphicon glyphicon-trash'aria-hidden='true'></span></button></td>";
                    echo "</tr>";
                
                   }
                    
                    ?>
                </tbody>
              </table>
              
        </div>
        </div>
        

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
