<?php
require "dbcon.php";

if(isset($_GET["save"]))
{
    $sid=$_GET["txts"];
    $sname=$_GET["txtn"];
    $sbank=$_GET["txtb"];
    $sql="insert into assignbranch(sid,sname,branch) values('$sid','$sname','$sbank')";
    mysqli_query($con,$sql);
    echo "<script>alert('record saved')</script>";
    $extra="usertype.php";
    $host=$_SERVER['HTTP_HOST'];
    $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    echo "<script>open('http://$host$uri/$extra','self')</script>";
    mysqli_close($con);
    }
    
    elseif (isset($_GET["action"]))
    {
        $id= $_GET["id"];
        $sql="delete from usertype where id='$id'";
        echo "record delete";
        mysqli_query($con,$sql);
        $extra="usertype.php";
    $host=$_SERVER['HTTP_HOST'];
    $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    echo "<script>open('http://$host$uri/$extra','self')</script>";
    
        mysqli_close($con);
    
    }
    else{
        $sql="update usertype setid='$id'.userty='$type'";
        mysqli_query($con,$sql);
        mysqli_close($con);
    }
    
    
?>