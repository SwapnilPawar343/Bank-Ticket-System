<?php
require "dbcon.php";
$ut=$_GET["txtut"];
$si=$_GET["txtsi"];
$sn=$_GET["txtsn"];
$an=$_GET["txtan"];
$b=$_GET["txtbank"];
$mob=$_GET["txtm"];
$pass=$_GET["txtpass"];
$rpass=$_GET["txtpassr"];
echo "narayan";
$sql="insert into staff(ut,staffid,staffn,admin,branch,mob,pass,rpass)value('$ut','$si','$sn','$an','$b','$mob','$pass','$rpass')";

mysqli_query($con,$sql);
echo "<script>alert('record saved')</script>";
$extra="usertype.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
echo "<script>open('http://$host$uri/$extra','self')</script>";
mysqli_close($con);
}

elseif (isset($_GET["action"]))
{
    $id= $_GET["id"];
    $sql="delete from usertype where id='$id'";
    echo "record delete";
    mysqli_query($con,$sql);
    $extra="usertype.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
echo "<script>open('http://$host$uri/$extra','self')</script>";

    mysqli_close($con);

}
else{
    $sql="update usertype setid='$id'.userty='$type'";
    mysqli_query($con,$sql);
    mysqli_close($con);
}


mysqli_close($con);
?>