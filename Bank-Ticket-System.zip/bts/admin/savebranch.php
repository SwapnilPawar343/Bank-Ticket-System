<?php
require "dbcon.php";
if (isset($_GET["save"])) {
$id=$_GET["txtbranch"];
$branch=$_GET["txtbank"];
$city=$_GET["txtbranchc"];
$mob=$_GET["txtnum"];
$sql="insert into addbranch(branchid,branchname,branchcity,mob)value('$id','$branch','$city','$mob')";
mysqli_query($con,$sql);
echo "save";
mysqli_close($con);
}
elseif (isset($_GET["action"])) {
    $id= $_GET["id"];
    $sql="delete from addbranch where branchid='$id'";
    echo "record delete";
    mysqli_query($con,$sql);
    $extra="branch.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
echo "<script>open('http://$host$uri/$extra','self')</script>";

    mysqli_close($con);
}
?>