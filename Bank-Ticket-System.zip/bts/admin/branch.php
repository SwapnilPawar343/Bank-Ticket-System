
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script>
        function checkvalue()
        {
            var uid=document.getElementById("txtbranch").value;
        
            if (uid=="" || uid==null) {
                    alert("Enter Valid id")
                    return false;
                }
               var num=document.getElementById("txtnum").value;
                 
                    
                 
                while (num.length!=10) 
                {
                    alert("Eneter valid mob number");
                    return false;
                    
                }
                var bname=document.getElementById("txtbranch").value
               if (bname=="" || bname==null) {
                    alert("enter Branch Name");
                    return false;
                    
                }
                
                
                else{
                    alert("Wellcome");
            return true;}
                
        }
        

        </script>
    </head>
    <body>
        
        <?php
        include("include/header.html")
        ?>
        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
        <?php
        include("include/sidemenu.html")
        ?> </div>
        
        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
            
        
        
        <div class="panel panel-info">
              <div class="panel-heading">
                    <h3 class="panel-title">Manage Branch</h3>
              </div>
              <div class="panel-body">
            
            <form action="savebranch.php" method="get" role="form" onsubmit="return checkvalue()">
                
            
            <div class="form-group">
                    <label for="">Branch Id</label>
                    <input type="number" class="form-control" id="txtbranch"name="txtbranch" placeholder="Enter branch id">
                </div>
                <div class="form-group">
                <label for="">branch</label>  <select name="txtbank" id="textbank" class="form-control" required="required2>
                        <option value="bank of maharastra beed>bank of maharasta beed</option>
                        <option value="bank of maharastra neknur">bank of maharastra Neknur</option>
                        <option value="bank of maharastra chousala">bank of maharastra chousala </option>
                        <option value="bank of maharastra vadvani"> bank of maharastra Vadvani</option>
                        <option value="bank of maharastra ambajogai"> bank of maharasta Ambajogai</option>
                        <option value="bank of maharastra yellambh"> bank of maharastra Yellambh</option>
                        <option value="bank of maharastra nandur">bank of maharastra Nandur</option>
                    </select>           </div>
                <div class="form-group">
                    <label for="">Branch City</label>
                    <input type="text" class="form-control" id="txtbranchc"name="txtbranchc" placeholder="Enter branch City">
                </div>
                <div class="form-group">
                    <label for="">Mobile.no</label>
                    <input type="number" class="form-control" id="txtnum"name="txtnum" placeholder="Enter Mobile no.">
                </div>




            
                
            
                <button type="submit" class="btn btn-primary"name="save" value="save">add branch</button>

            </form>
            
        </div>
        <div>
                    
        
              <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Branch Id</th>
                        <th>Branch name</th>
                        <th>Branch city</th>
                        <th>Mob.no</th>
                        <th>option</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                      require ("dbcon.php");
                      $sql="select *from addbranch";
                      $res=mysqli_query($con,$sql);
                      while ($r=mysqli_fetch_array($res)) {
                        echo "<tr>";
                        echo "<td>".$r[0]."</td>";
                        echo "<td>".$r[1]."</td>";
                        echo "<td>".$r[2]."</td>";
                        echo "<td>".$r[3]."</td>";
                        echo "<td><a href='savebranch.php?action=remove&id=".$r[0]."'role='button'class='btn btn-danger'><span class='glyphicon glyphicon-trash'aria-hidden='true'></span></button></td>";
                    echo "</tr>";
                        echo "</tr>";
                      }

                      ?>
                </tbody>
              </table>
              
        </div>
        </div>
      

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
