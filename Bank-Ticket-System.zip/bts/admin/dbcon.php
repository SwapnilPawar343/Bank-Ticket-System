<?php
$host="localhost";
$user="root";
$pass="";
$dbname="btsproject";
$con=mysqli_connect($host,$user,$pass,$dbname);
?>