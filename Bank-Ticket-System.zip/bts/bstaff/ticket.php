
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
    <div class="container">
        
    
    <div class="panel panel-primary">
          <div class="panel-heading">
                <h3 class="panel-title">Ticket</h3>
          </div>
          <div class="panel-body">
            
          
    
    
    
        
        <?php
        require "dbcon.php";
        $sql="select max(ticketid) from ticket";
        $res= mysqli_query($con,$sql);
        $r=mysqli_fetch_array($res);

        ?>
        <form action="saveticket.php" method="get" role="form">
            <legend></legend>
            <div class="<div class="form-group>
                <label for="">Date</label>
                <input type="date" class="form-control" id="txtd" name="txtd" placeholder="Input field">
        </div>
        
            <div class="form-group">
                <label for="">Ticket no</label>
                <input type="number" class="form-control" id="txtn"name="txtn" value="<?php echo( $r[0]+1)?>"readonly placeholder="Input field"><?php
                mysqli_close($con);
                ?>
            </div>
            <div class="<div class="form-group>
                <label for=""> Subject</label>
                <input type="text" class="form-control" id="txts" name="txts" placeholder="Enter Subject">
        </div>
            <div>
            <label for="">message</label>
                <textarea name="message" id="message" class="form-control" rows="10" required="required" maxlength="250"></textarea>
                
        </div>
        <div class="<div class="form-group>
                <label for=""> Attachment</label>
                <input type="file" class="form-control" id="txtf" name="txtf" placeholder="Input field">
        </div>
        <div class="<div class="form-group>
                <label for="">Bank Name</label>
                <input type="text" class="form-control" id="txtb" name="txtb" placeholder="Input field">
        </div>  <div class="panel panel-primary">
              <div class="panel-heading">
                    <h3 class="panel-title">Ticket</h3>
              </div>
              <div class="panel-body">
                    
              
        
        
        
        <table class="table table-bordered table-hover">
<thead>
    <th>date</th>
    <th>Ticket no.</th>
    <th>Subject</th>
    <th>Message</th>
    <th>File</th>
    <th>Bank</th>
    
    
    

            <tbody>
                
           
    <?php
                    require "dbcon.php";
                    $sql="select *from ticket";
                   $res= mysqli_query($con,$sql);
                   while ($r=mysqli_fetch_array($res)) {
                    echo "<tr id='t1'>";
                    echo "<td>".$r[0]."</td>";
                    echo "<td>".$r[1]."</td>";
                    echo "<td>".$r[2]."</td>";
                    echo "<td>".$r[3]."</td>";
                    echo "<td>".$r[4]."</td>";
                    echo "<td>".$r[5]."</td>";
                    echo "<td>".$r[6]."</td>";
                    echo "</tr>";
                   }
                   mysqli_close($con);
                   ?>
                    </tbody>
                    </table>
                </div>
      
        
        

        
            
        
            <button type="submit" class="btn btn-primary" value="save" name="save">Submit</button>
        </form>
        </div></div>

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
