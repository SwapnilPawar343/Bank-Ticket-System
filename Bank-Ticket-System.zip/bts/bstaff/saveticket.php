<?php
require "dbcon.php";
if (isset($_GET["save"])){
    $date=$_GET["txtd"];
    $ticket=$_GET["txtn"];
    $sub=$_GET["txts"];
    $message=$_GET["message"];
    $file=$_GET["txtf"];
    $bank=$_GET["txtb"];
    $sql="insert into ticket(date,ticketid,subject,message,file,bank)values('$date','$ticket','$sub','$message','$file','$bank')";
    mysqli_query($con,$sql);
    mysqli_close($con);
}
?>